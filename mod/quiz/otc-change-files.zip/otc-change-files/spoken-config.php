<?php
    mysql_connect("localhost", "root", "root") or die("cannot connect");
    mysql_select_db("spoken") or die("cannot select DB");
?>
